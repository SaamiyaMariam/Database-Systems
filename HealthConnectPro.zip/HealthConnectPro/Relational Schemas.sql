CREATE TABLE Ward(
WardNo NUMERIC,
WardName varchar(30),
Location varchar(30),
Specialty varchar(30),
NoOfNurses NUMERIC,
NoOfBeds NUMERIC,
CONSTRAINT PK_Ward PRIMARY KEY (WardNo));

CREATE TABLE CareUnit(
CareUnitNo NUMERIC,
CareUnitName varchar(30),
WardNo NUMERIC,
CONSTRAINT PK_CareUnit PRIMARY KEY (CareUnitNo),
CONSTRAINT FK_CareUnit FOREIGN KEY (WardNo) REFERENCES Ward(WardNo));

CREATE TABLE Nurse(
NurseID NUMERIC,
NurseName varchar(30),
Type varchar(30),
Gender varchar(10),
StartDate DATE,
PhoneNo NUMERIC,
Age NUMERIC,
WardNo NUMERIC,
CareUnitNo NUMERIC,
CONSTRAINT PK_Nurse PRIMARY KEY (NurseID),
CONSTRAINT FK_NurseCU FOREIGN KEY (CareUnitNo) REFERENCES CareUnit(CareUnitNo),
CONSTRAINT FK_NurseW FOREIGN KEY (WardNo) REFERENCES Ward(WardNo));

CREATE TABLE Team(
TeamNo NUMERIC,
TeamName varchar(30),
CONSTRAINT PK_Team PRIMARY KEY (TeamNo));

CREATE TABLE Doctor(
StaffNo NUMERIC,
TeamNo NUMERIC,
Name varchar(30),
Position varchar(20),
Gender varchar(15),
JoinDate DATE,
ConsultantNo NUMERIC,
Specialty varchar(30),
CONSTRAINT PK_Doctor PRIMARY KEY (StaffNo),
CONSTRAINT FK_Doctor FOREIGN KEY (TeamNo) REFERENCES Team(TeamNo));

CREATE TABLE PreviousExperience(
SerialNo NUMERIC,
StaffNo NUMERIC,
Establishment varchar(20),
FromDate DATE,
ToDate DATE,
CONSTRAINT PK_PrevExp PRIMARY KEY (SerialNo),
CONSTRAINT FK_PrevExp FOREIGN KEY (StaffNo) REFERENCES Doctor(StaffNo));


CREATE TABLE Progress(
SerialNo NUMERIC,
StaffNo NUMERIC,
ProgDate DATE,
Performance varchar(40),
Grade varchar(10),
CONSTRAINT PK_Progress PRIMARY KEY (SerialNo),
CONSTRAINT FK_Progress FOREIGN KEY (StaffNo) REFERENCES Doctor(StaffNo));


CREATE TABLE Patient(
PatientNo NUMERIC,
Name varchar(20),
CareUnitNo NUMERIC,
StaffNo NUMERIC,
BedNo NUMERIC,
Gender varchar(15),
DOB Date,
Age NUMERIC,
FatherName varchar(20),
Address varchar(40),
PhoneNumber NUMERIC,
AdmitDate Date,
CONSTRAINT PK_Patient PRIMARY KEY (PatientNo),
CONSTRAINT FK_PatientCU FOREIGN KEY (CareUnitNo) REFERENCES CareUnit(CareUnitNo),
CONSTRAINT FK_PatientDoc FOREIGN KEY (StaffNo) REFERENCES Doctor(StaffNo));


CREATE TABLE Complaint(
ComplaintCode NUMERIC,
PatientNo NUMERIC,
StaffNo NUMERIC,
ComplaintDate Date,
Description varchar(40),
CONSTRAINT PK_Complaint PRIMARY KEY (ComplaintCode),
CONSTRAINT FK_ComplaintPatient FOREIGN KEY (PatientNo) REFERENCES Patient(PatientNo),
CONSTRAINT FK_ComplaintDoc FOREIGN KEY (StaffNo) REFERENCES Doctor(StaffNo));

CREATE TABLE Treatment(
TreatmentCode NUMERIC,
ComplaintCode NUMERIC,
StaffNo NUMERIC,
StartDate Date,
EndDate Date,
Description varchar(40),
CONSTRAINT PK_Treatment PRIMARY KEY (TreatmentCode),
CONSTRAINT FK_TreatmentComp FOREIGN KEY (ComplaintCode) REFERENCES Complaint(ComplaintCode),
CONSTRAINT FK_TreatmentDoc FOREIGN KEY (StaffNo) REFERENCES Doctor(StaffNo));



/* INSERTION STATEMENTS */

/*	WARD	*/
INSERT INTO Ward
VALUES (1, 'Orthopedic', 'IVOR PAINE MEMORIAL HOSPITAL', 'Orthopedic', 3, 3);

INSERT INTO Ward
VALUES (2, 'Oncology', 'IVOR PAINE MEMORIAL HOSPITAL', 'Oncology', 5, 3);

INSERT INTO Ward
VALUES (3, 'Geriatric', 'IVOR PAINE MEMORIAL HOSPITAL', 'Geriatric', 4, 2);

INSERT INTO Ward
VALUES (4, 'Pediatric', 'IVOR PAINE MEMORIAL HOSPITAL', 'Pediatric', 4, 3);

INSERT INTO Ward
VALUES (5, 'Dementia', 'IVOR PAINE MEMORIAL HOSPITAL', 'Dementia', 3, 2);

INSERT INTO Ward
VALUES (6, 'Rheumatology', 'IVOR PAINE MEMORIAL HOSPITAL', 'Rheumatology', 3, 2);

INSERT INTO Ward
VALUES (7, 'Respiratory', 'IVOR PAINE MEMORIAL HOSPITAL', 'Respiratory', 5, 3);

INSERT INTO Ward
VALUES (8, 'Cardiothoracic', 'IVOR PAINE MEMORIAL HOSPITAL', 'Cardiothoracic', 4, 4);

/*	CARE UNIT	*/
INSERT INTO CareUnit
VALUES (1, 'Orthopedic01', 1);
INSERT INTO CareUnit
VALUES (2, 'Orthopedic02', 1);
INSERT INTO CareUnit
VALUES (3, 'Orthopedic03', 1);
INSERT INTO CareUnit
VALUES (4, 'Oncology01', 2);
INSERT INTO CareUnit
VALUES (5, 'Oncology02', 2);
INSERT INTO CareUnit
VALUES (6, 'Oncology03', 2);
INSERT INTO CareUnit
VALUES (7, 'Oncology04', 2);
INSERT INTO CareUnit
VALUES (8, 'Oncology05', 2);
INSERT INTO CareUnit
VALUES (9, 'Geriatric01', 3);
INSERT INTO CareUnit
VALUES (10, 'Geriatric02', 3);
INSERT INTO CareUnit
VALUES (11, 'Geriatric03', 3);
INSERT INTO CareUnit
VALUES (12, 'Geriatric04', 3);
INSERT INTO CareUnit
VALUES (13, 'Pediatric01', 4);
INSERT INTO CareUnit
VALUES (14, 'Pediatric02', 4);
INSERT INTO CareUnit
VALUES (15, 'Pediatric03', 4);
INSERT INTO CareUnit
VALUES (16, 'Pediatric04', 4);
INSERT INTO CareUnit
VALUES (17, 'Dementia01', 5);
INSERT INTO CareUnit
VALUES (18, 'Dementia02', 5);
INSERT INTO CareUnit
VALUES (19, 'Dementia03', 5);
INSERT INTO CareUnit
VALUES (20, 'Rheumatology01', 6);
INSERT INTO CareUnit
VALUES (21, 'Rheumatology02', 6);
INSERT INTO CareUnit
VALUES (22, 'Rheumatology03', 6);
INSERT INTO CareUnit
VALUES (23, 'Respiratory01', 7);
INSERT INTO CareUnit
VALUES (24, 'Respiratory02', 7);
INSERT INTO CareUnit
VALUES (25, 'Respiratory03', 7);
INSERT INTO CareUnit
VALUES (26, 'Respiratory04', 7);
INSERT INTO CareUnit
VALUES (27, 'Respiratory05', 7);
INSERT INTO CareUnit
VALUES (28, 'Cardiothoracic01', 8);
INSERT INTO CareUnit
VALUES (29, 'Cardiothoracic02', 8);
INSERT INTO CareUnit
VALUES (30, 'Cardiothoracic03', 8);
INSERT INTO CareUnit
VALUES (31, 'Cardiothoracic04', 8);

/*	NURSE	*/
INSERT INTO Nurse
VALUES (1, 'Afia Ahmad', 'Day Sister','Female','2015-12-17', 03005469875, 39, 1,1 );

INSERT INTO Nurse
VALUES (2, 'Ayaz Kamran', 'Night Sister', 'Male','2016-11-23', 03205463515, 28, 1,2 );

INSERT INTO Nurse
VALUES (3, 'Maryam Tanvir','Staff Nurse', 'Female','2020-10-03', 03277723515, 22, 1,1 );

INSERT INTO Nurse
VALUES (32, 'Maryam Ali','Staff Nurse', 'Female','2020-10-03', 03277729991, 22, 1,2 );

INSERT INTO Nurse
VALUES (33, 'Sanaa Alvi','Staff Nurse', 'Female','2020-10-03', 03277783547, 22, 1,3 );

INSERT INTO Nurse
VALUES (34, 'Sara Alvi','Non-Registered', 'Female','2020-10-03', 03255443547, 25, 1,1);

INSERT INTO Nurse
VALUES (4, 'Alina Saad', 'Staff Nurse', 'Female','2020-09-03', 03299870515, 23, 2,1 );
INSERT INTO Nurse
VALUES (5, 'Husnain Khan','Staff Nurse', 'Male','2018-08-22', 03277650515, 22, 2,2 );
INSERT INTO Nurse
VALUES (6, 'Ayan Ahmad', 'Staff Nurse','Male','2012-04-09', 03201250415, 40, 2,3 );
INSERT INTO Nurse
VALUES (7, 'Shaheer Niazi', 'Staff Nurse','Male','2018-02-13', 03274442215, 24, 2,4 );
INSERT INTO Nurse
VALUES (8, 'Maha Batool', 'Staff Nurse','Female','2009-03-31', 03266339815, 35, 2,5 );
INSERT INTO Nurse
VALUES (35, 'Mehreen Ahmed', 'Day Sister','Female','2009-03-31', 03266222247, 35, 2,5 );
INSERT INTO Nurse
VALUES (36, 'Ramsha Haider', 'Night Sister','Female','2009-03-31', 03266339977, 37, 2,5 );
INSERT INTO Nurse
VALUES (37, 'Raza Haider', 'Non-Registered','Male','2008-03-31', 03266888888, 32, 2,5 );

INSERT INTO Nurse
VALUES (9, 'Irtaza Bhatti', 'Staff Nurse', 'Male','2010-06-18', 03200253311, 32, 3,1 );
INSERT INTO Nurse
VALUES (10, 'Sania Azhaan', 'Staff Nurse', 'Female','2012-04-09', 03201259912, 40, 3,2 );
INSERT INTO Nurse
VALUES (11, 'Shafia Hasan', 'Staff Nurse', 'Female','2021-10-10', 03201444435, 25, 3,3 );
INSERT INTO Nurse
VALUES (12, 'Hassan Rayan', 'Staff Nurse', 'Male','2021-04-25', 03201233126, 24, 3,4 );
INSERT INTO Nurse
VALUES (38, 'Usman Ali', 'Day Sister', 'Male','2021-04-25', 03480870779, 24, 3,4 );
INSERT INTO Nurse
VALUES (39, 'Muhammad Danial', 'Night Sister', 'Male','2021-04-25', 03486205469, 24, 3,4 );
INSERT INTO Nurse
VALUES (40, 'Abdur Rehman', 'Non-Registered', 'Male','2021-04-25', 03387607433, 24, 3,4 );


INSERT INTO Nurse
VALUES (13, 'Nadim Bhatti', 'Staff Nurse', 'Male','1993-10-21', 03208734507, 41, 4,1 );
INSERT INTO Nurse
VALUES (14, 'Seema Abdul', 'Staff Nurse', 'Female','1997-04-04', 03642953043, 55, 4,2 );
INSERT INTO Nurse
VALUES (15, 'Maria Fatima', 'Staff Nurse', 'Female','2002-04-19', 03185858333, 45, 4,3 );
INSERT INTO Nurse
VALUES (16, 'Rohan Irshad', 'Staff Nurse', 'Male','2020-04-21', 03879582432, 33, 4,4 );
INSERT INTO Nurse
VALUES (41, 'Rahmeen Bajwa', 'Day Sister', 'Female','1999-09-09', 03222574836, 35, 4,4 );
INSERT INTO Nurse
VALUES (42, 'Sabah Rafiq', 'Night Sister', 'Female','1999-04-06', 03283679690, 36, 4,4 );
INSERT INTO Nurse
VALUES (43, 'Saeeda Rafiq', 'Non-Registered', 'Female','2000-04-01', 03464116036, 36, 4,4 );

INSERT INTO Nurse
VALUES (17, 'Tabassum Bhatti', 'Staff Nurse', 'Female','1994-08-02', 03986451665, 52, 5,1 );
INSERT INTO Nurse
VALUES (18, 'Nisha Wasim', 'Staff Nurse', 'Female','2005-08-08', 03878338901, 31, 5,2 );
INSERT INTO Nurse
VALUES (19, 'Aman Rizwan', 'Staff Nurse', 'Male','2016-05-06', 03703857558, 29, 5,3 );
INSERT INTO Nurse
VALUES (44, 'Sher Ali', 'Day Sister', 'Male','2016-05-06', 03127426990, 39, 5,3 );
INSERT INTO Nurse
VALUES (45, 'Sikandar Sohail', 'Night Sister', 'Male','2021-02-04', 03803134480, 25, 5,3 );
INSERT INTO Nurse
VALUES (46, 'Subhan Umar', 'Non-Registered', 'Male','2007-12-29', 03313980085, 29, 5,3 );

INSERT INTO Nurse
VALUES (20, 'Rashid Shahid', 'Staff Nurse', 'Male','1993-07-12', 03859096989, 61, 6,1 );
INSERT INTO Nurse
VALUES (21, 'Babar Faisal', 'Staff Nurse', 'Male','2005-06-11', 03507599883, 36, 6,2 );
INSERT INTO Nurse
VALUES (22, 'Deepak Ramesh', 'Staff Nurse', 'Male','2015-11-22', 03614316927, 34, 6,3 );
INSERT INTO Nurse
VALUES (47, 'Talha Usman', 'Day Sister', 'Male','2015-11-22', 03205207044, 34, 6,3 );
INSERT INTO Nurse
VALUES (48, 'Vijay Ramesh', 'Night Sister', 'Male','2015-11-22', 03614316927, 55, 6,3 );
INSERT INTO Nurse
VALUES (50, 'Syed Talal', 'Non-Registered', 'Male','2005-04-22', 03655316927, 66, 6,3 );

INSERT INTO Nurse
VALUES (23, 'Fariha Zaki', 'Staff Nurse', 'Female','1992-08-17', 03518794651, 47, 7,1 );
INSERT INTO Nurse
VALUES (24, 'Gulbadan Furqan', 'Staff Nurse', 'Female','2015-01-02', 03992363671, 37, 7,2 );
INSERT INTO Nurse
VALUES (25, 'Habib Hayat', 'Staff Nurse', 'Male','1996-05-16', 03977248371, 49, 7,3 );
INSERT INTO Nurse
VALUES (26, 'Imtiyaz Jehangir', 'Staff Nurse', 'Male','2022-06-18', 03128369274, 34, 7,4 );
INSERT INTO Nurse
VALUES (27, 'Halima Imran', 'Staff Nurse', 'Female','2017-01-25', 03171452926, 31, 7,5 );
INSERT INTO Nurse
VALUES (51, 'Zarina Zahid', 'Day Sister', 'Female','1996-08-22', 03154876225, 34, 7,5 );
INSERT INTO Nurse
VALUES (52, 'Muhammad Zahid', 'Night Sister', 'Male','1998-04-17', 03978282125, 44, 7,5 );
INSERT INTO Nurse
VALUES (53, 'Shakeel Kazmi', 'Non-Registered', 'Male','1998-04-17', 03494436487, 44, 7,5 );

INSERT INTO Nurse
VALUES (28, 'Naseem Muraad', 'Staff Nurse', 'Female','1993-10-09', 03330293277, 45, 8,1 );
INSERT INTO Nurse
VALUES (29, 'Saeeda Umar', 'Staff Nurse', 'Female','2012-01-05', 03106294034, 37, 8,2 );
INSERT INTO Nurse
VALUES (30, 'Maqsood Latif', 'Staff Nurse', 'Male','1999-12-18', 03849279965, 55, 8,3 );
INSERT INTO Nurse
VALUES (31, 'Muhammad Mukhtar', 'Staff Nurse', 'Male','2018-02-09', 03428330014, 26, 8,4 );
INSERT INTO Nurse
VALUES (54, 'Zulfiqar Aslam', 'Day Sister', 'Male','2015-02-11', 03205338749, 28, 8,4 );
INSERT INTO Nurse
VALUES (55, 'Hamza Tahir', 'Night Sister', 'Male','2020-08-14', 03763736043, 29, 8,4 );
INSERT INTO Nurse
VALUES (56, 'Shahzad Shafi', 'Non-Registered', 'Male','1994-08-22', 03967116905, 26, 8,4 );

/* TEAM	*/
INSERT INTO Team
VALUES (1, 'Orthopedic' );
INSERT INTO Team
VALUES (2, 'Oncology' );
INSERT INTO Team
VALUES (3, 'Geriatric' );
INSERT INTO Team
VALUES (4, 'Pediatric' );
INSERT INTO Team
VALUES (5, 'Dementia' );
INSERT INTO Team
VALUES (6, 'Rheumatology' );
INSERT INTO Team
VALUES (7, 'Respiratory' );
INSERT INTO Team
VALUES (8, 'Cardiothoracic' );

/*	DOCTOR	*/
INSERT INTO Doctor
VALUES (1, 1, 'Yasmeen Zafar', 'consultant', 'Female', '1993-10-09', 1, 'Orthopedic');
INSERT INTO Doctor
VALUES (2, 1, 'Asma Sajid', 'jh', 'Female', '2003-11-09', 1, 'Orthopedic');
INSERT INTO Doctor
VALUES (3, 1, 'Malik Khalid', 'ar', 'Male', '1999-07-23', 1, 'Orthopedic');

INSERT INTO Doctor
VALUES (4, 2, 'Abdul Bari', 'consultant', 'Male', '1999-12-12', 4, 'Oncology');
INSERT INTO Doctor
VALUES (5, 2, 'Laiba Gul', 's', 'Female', '2017-11-08', 4, 'Oncology');
INSERT INTO Doctor
VALUES (6, 2, 'Raheem Peerzada', 'r', 'Male', '1995-05-12', 4, 'Oncology');

INSERT INTO Doctor
VALUES (7, 3, 'Shazia Shams', 'consultant', 'Female', '1992-07-20', 7, 'Geriatric');
INSERT INTO Doctor
VALUES (8, 3, 'Sadiqa Rana', 'sh', 'Female', '2011-07-13', 7, 'Geriatric');
INSERT INTO Doctor
VALUES (9, 3, 'Qasim Rafiq', 'ar', 'Male', '2001-07-15', 7, 'Geriatric');

INSERT INTO Doctor
VALUES (10, 4, 'Mehmud Rafiq', 'consultant', 'Male', '2005-08-11', 10, 'Dementia');
INSERT INTO Doctor
VALUES (11, 4, 'Raza Shahzad', 'r', 'Male', '2004-12-18', 10, 'Dementia');
INSERT INTO Doctor
VALUES (12, 4, 'Zaman Zubair', 'jh', 'Male', '2007-02-27', 10, 'Dementia');

INSERT INTO Doctor
VALUES (13, 5, 'Bushra Fateh', 'consultant', 'Female', '1997-06-12', 13, 'Rheumatology');
INSERT INTO Doctor
VALUES (14, 5, 'Hafsa Hameed', 'sh', 'Female', '2010-10-21', 13, 'Rheumatology');
INSERT INTO Doctor
VALUES (15, 5, 'Maryam Shafia', 'sh', 'Female', '2008-03-17', 13, 'Rheumatology');

INSERT INTO Doctor
VALUES (16, 6, 'Amir Arif', 'consultant', 'Male', '1997-06-13', 16, 'Respiratory');
INSERT INTO Doctor
VALUES (17, 6, 'Hafsa Azeez', 'r', 'Female', '2010-11-21', 16, 'Respiratory');
INSERT INTO Doctor
VALUES (18, 6, 'Maryam Danish', 'jh', 'Female', '2007-06-27', 16, 'Respiratory');

INSERT INTO Doctor
VALUES (19, 7, 'Farhan Khan', 'consultant', 'Male', '2006-07-05', 17, 'Pediatric');
INSERT INTO Doctor
VALUES (20, 7, 'Hira Imran', 'ar', 'Female', '2017-02-17', 17, 'Pediatric');
INSERT INTO Doctor
VALUES (21, 7, 'Iqra Irshad', 'jh', 'Female', '1999-02-12', 17, 'Pediatric');

INSERT INTO Doctor
VALUES (22, 8, 'Kausar Ahmad', 'consultant', 'Female', '2000-07-08', 20, 'Cardiothoracic');
INSERT INTO Doctor
VALUES (23, 8, 'Jawed Bashir', 'jh', 'Male', '2005-01-31', 20, 'Cardiothoracic');
INSERT INTO Doctor
VALUES (24, 8, 'Muhammad Rahim', 'sh', 'Male', '2019-08-09', 20, 'Cardiothoracic');




/*	PREVIOUS EXPEIENCE	*/
INSERT INTO PreviousExperience
VALUES (1, 1, 'Shifa Hospital', '1991-02-02', '1993-09-09' );
INSERT INTO PreviousExperience
VALUES (2, 2, 'PIMS Hospital', '2000-01-19', '2001-10-10' );
INSERT INTO PreviousExperience
VALUES (3, 2, 'Shifa Hospital', '2001-01-02', '2003-10-10' );

INSERT INTO PreviousExperience
VALUES (4, 3, 'PIMS Hospital', '1990-09-03', '1997-10-10' );
INSERT INTO PreviousExperience
VALUES (5, 4, 'PAEC Hospital', '1995-09-03', '1998-08-10' );
INSERT INTO PreviousExperience
VALUES (6, 5, 'PAEC Hospital', '2010-11-03', '2017-11-10' );

INSERT INTO PreviousExperience
VALUES (7, 6, 'Kulsum Intl Hospital', '1990-09-03', '1995-05-10' );
INSERT INTO PreviousExperience
VALUES (8, 7, 'Shifa Hospital', '1990-09-03', '1992-10-10' );
INSERT INTO PreviousExperience
VALUES (9, 8, 'PAF Hospital', '1990-09-03', '2011-11-11' );
INSERT INTO PreviousExperience
VALUES (10, 9, 'Maroof Hospital', '1997-09-21', '2001-07-10' );

INSERT INTO PreviousExperience
VALUES (11, 10, 'CMH', '1999-10-03', '2005-08-10' );
INSERT INTO PreviousExperience
VALUES (12, 11, 'CMH', '1999-12-03', '2004-08-10' );
INSERT INTO PreviousExperience
VALUES (13, 12, 'Maroof', '2001-07-20', '2006-08-10' );

INSERT INTO PreviousExperience
VALUES (14, 13, 'QuaideAzam Hospital', '1995-10-03', '1996-02-10' );
INSERT INTO PreviousExperience
VALUES (15, 14, 'NORI Hospital', '1999-12-03', '2010-08-13' );
INSERT INTO PreviousExperience
VALUES (16, 15, 'LifeCare Hsptl', '2001-07-20', '2008-03-10' );

INSERT INTO PreviousExperience
VALUES (17, 16, 'QuaideAzam Hospital', '1995-10-03', '1997-05-10' );
INSERT INTO PreviousExperience
VALUES (18, 17, 'NORI Hospital', '1999-12-03', '2010-08-13' );
INSERT INTO PreviousExperience
VALUES (19, 18, 'LifeCare Hsptl', '2003-07-20', '2007-03-10' );

INSERT INTO PreviousExperience
VALUES (20, 19, 'Alam Hospital', '1995-10-03', '2005-05-02' );
INSERT INTO PreviousExperience
VALUES (21, 20, 'KRL Hospital', '2002-12-30', '2016-08-13' );
INSERT INTO PreviousExperience
VALUES (22, 21, 'Benazir Bh Hsptl', '1992-07-29', '1998-03-10' );

INSERT INTO PreviousExperience
VALUES (23, 22, 'PAEC Hospital', '1995-10-03', '2000-05-02' );
INSERT INTO PreviousExperience
VALUES (24, 23, 'PAF Hospital', '2002-12-30', '2005-01-13' );
INSERT INTO PreviousExperience
VALUES (25, 24, 'Benazir Bh Hsptl', '2016-06-26', '2019-03-12' );

/*	PROGRESS	*/
INSERT INTO Progress
VALUES (1, 2, '2004-05-09', 'Good', 'A');
INSERT INTO Progress
VALUES (2, 2, '2004-11-09', 'Acceptable','B');
INSERT INTO Progress
VALUES (3, 2, '2005-05-09', 'Impressive','A');
INSERT INTO Progress
VALUES (4, 2, '2005-11-09', 'Capable','B');
INSERT INTO Progress
VALUES (5, 2, '2006-05-09', 'Exemplary','A');
INSERT INTO Progress
VALUES (6, 2, '2006-11-09', 'Passable','C');
INSERT INTO Progress
VALUES (7, 2, '2007-05-09', 'Improving', 'B');

INSERT INTO Progress
VALUES (8, 3, '1999-07-09', 'Acceptable','B');
INSERT INTO Progress
VALUES (9, 3, '2000-01-09', 'Capable','B');
INSERT INTO Progress
VALUES (10, 3, '2000-07-09','Remarkable', 'A');
INSERT INTO Progress
VALUES (11, 3, '2001-01-09', 'Praiseworthy','A');
INSERT INTO Progress
VALUES (12, 3, '2001-07-09', 'Exemplary','A');
INSERT INTO Progress
VALUES (13, 3, '2002-01-09','Impressive', 'A');
INSERT INTO Progress
VALUES (14, 3, '2002-07-09', 'Impressive','A');
INSERT INTO Progress
VALUES (15, 3, '2003-01-09','Acceptable', 'B');
INSERT INTO Progress
VALUES (16, 3, '2003-07-09', 'Brilliant','A');
INSERT INTO Progress
VALUES (17, 5, '2017-11-08','Impressive', 'A');
INSERT INTO Progress
VALUES (18, 6, '1995-05-12','Satisfactory', 'B');
INSERT INTO Progress
VALUES (19, 8, '2011-07-13', 'Impressive','A');
INSERT INTO Progress
VALUES (20, 9, '2001-07-15', 'Satisfactory','B');
INSERT INTO Progress
VALUES (21, 11, '2004-12-18','Excellent', 'A');
INSERT INTO Progress
VALUES (22, 12, '2007-02-27','Excellent', 'A');
INSERT INTO Progress
VALUES (23, 14, '2010-10-21', 'Excellent','A');
INSERT INTO Progress
VALUES (24, 15, '2008-03-17','Passable', 'C');
INSERT INTO Progress
VALUES (25, 17, '2010-11-21', 'Excellent','A');
INSERT INTO Progress
VALUES (26, 18, '2007-06-27','Passable', 'B');
INSERT INTO Progress
VALUES (27, 20, '2017-02-17','Impressive','A');
INSERT INTO Progress
VALUES (28, 21, '1999-02-12','Excellent', 'A');
INSERT INTO Progress
VALUES (29, 23, '2005-01-31','Excellent', 'A');
INSERT INTO Progress
VALUES (30, 24, '2019-08-09', 'Impressive','A');

/* PATIENTS */
Insert into Patient 
values(1,'Ayeza Malik',1,6,01,'Female','2001-09-03',21,'Ayan Malik','A-K Brohi Road',03315689023,'2022-10-10');

Insert into Patient 
values(2,'Hamza Khan',24,4,02,'Male','1999-12-10',22,'Zafar khan','6th Road',03327654890,'2021-12-13');

Insert into Patient 
values(3,'Fatima Zehra',17,01,03,'Female','1998-08-12',22,'Shoaib Khan','Satellite Town',03341278945,'2020-11-10');

Insert into Patient 
values(4,'Affan Ali',07,24,04,'Male','1997-09-18',25,'Shoaib Ali','H-11 Street-55',03301418912,'2022-12-05');

Insert into Patient 
values(5,'Urwa Fatima',2,03,01,'Female','2002-03-09',19,'Shakeel Awan','G-8 Street#25A',03327868686,'2021-10-10');

Insert into Patient 
values(6,'Nouroz Kareem',12,18,02,'Male','2003-10-12',19,'Kareem Sheikh','F-8 Street#03',03332656576,'2021-05-13');

Insert into Patient 
values(7,'Sumiya Abid',28,14,03,'Female','1996-12-08',23,'Abid Khan','G-10 Street#12',03319757543,'2019-11-10');

Insert into Patient 
values(8,'Ikram Faiz',06,21,04,'Male','1995-08-19',20,'Faiz Ahmed','G-11 Street#2A',03320801243,'2015-12-05');


Insert into Patient 
values(9,'Ayesha Sajid',10,16,03,'Female','2003-03-03',18,'Sajid Hussain','I-8 Street#4',03216543890,'2016-02-10');

Insert into Patient 
values(10,'Hamza Rauf',23,02,02,'Male','1999-01-10',19,'Rauf Alam','I-10 Street#04',033189056112,'2019-02-13');

Insert into Patient 
values(11,'Sawaira Fatima',18,11,01,'Female','1998-06-22',22,'Muhammad Akram','G9-1 Strret#9',03378223467,'2020-10-10');

Insert into Patient 
values(12,'Zubair Ashraf',15,23,04,'Male','1997-02-28',20,'Ashraf Khan','F-2 Street-55',03317676878,'2017-12-20');

Insert into Patient 
values(13,'Maleeha Masud',22,09,01,'Female','2004-01-01',22,'Masud Ali','E-2 Street#25A',03312233445,'2021-10-10');

Insert into Patient 
values(14,'Taha Atique',13,20,02,'Male','2003-03-26',19,'Atique ur Rehamn','I-8 Street#03',03318674454,'2022-05-25');

Insert into Patient 
values(15,'Rumaisa Anwar',21,17,03,'Female','1996-05-17',19,'Rana Anwar','Siddique Chowk 6th Road',0332267890,'2015-12-10');

Insert into Patient 
values(16,'Shehreyar Alam',30,04,04,'Male','1995-09-28',19,'Tufail Alam','Satellite Town 7th Road',03327786555,'2014-12-28');

/* COMPLAINTS */
INSERT INTO Complaint
VALUES (1, 1, 6, '2019-02-22', 'Lower-Back pain');
INSERT INTO Complaint
VALUES (2, 1, 6, '2019-03-22', 'Knee pain');
INSERT INTO Complaint
VALUES (3, 2, 4, '2020-02-24', 'Hip-Fracture');
INSERT INTO Complaint
VALUES (4, 2, 4, '2019-04-26', 'Post-Surgery Inflammation');

INSERT INTO Complaint
VALUES (5, 3, 1, '2008-06-16', 'Fatigue, Breathlessness');
INSERT INTO Complaint
VALUES (6, 4, 4, '2009-02-22', 'nausea, dizziness');

INSERT INTO Complaint
VALUES (7, 5, 3, '2019-02-22', 'Osteoporosis');
INSERT INTO Complaint
VALUES (8, 6, 18, '2020-05-02', 'Urinary Incontinence');

INSERT INTO Complaint
VALUES (9, 7, 14, '2004-05-16', 'Poor Nutrition');
INSERT INTO Complaint
VALUES (10, 8, 21, '2020-09-05', 'Disorientation');

INSERT INTO Complaint
VALUES (11, 9, 16, '2019-09-24', 'Joint Pain');
INSERT INTO Complaint
VALUES (12, 10, 2, '2020-10-19', 'Fever');

INSERT INTO Complaint
VALUES (13, 11, 11, '2014-09-11', 'Fatigue');
INSERT INTO Complaint
VALUES (14, 12, 23, '2020-10-19', 'Ear-Pain');

INSERT INTO Complaint
VALUES (15, 13, 9, '2014-09-11', 'Sore-Throat');
INSERT INTO Complaint
VALUES (16, 14, 20, '2020-10-19', 'Seizures');

INSERT INTO Complaint
VALUES (17, 15, 17, '2021-03-12', 'Cold Sweats, Fever');
INSERT INTO Complaint
VALUES (18, 16, 4, '2021-03-12', 'dizziness');


/* TREATMENT */
INSERT INTO Treatment
VALUES (1, 1, 6, '2019-02-22', '2019-02-28', 'start medication');
INSERT INTO Treatment
VALUES (2, 1, 6, '2019-02-28', '2019-03-02', 'progress made, stop meds');


INSERT INTO Treatment
VALUES (3, 2, 4, '2019-02-22', '2019-03-22', 'wear knee brace');
INSERT INTO Treatment
VALUES (4, 2, 4, '2019-03-22', '2019-03-31', 'start knee excersise');


INSERT INTO Treatment
VALUES (5, 3, 1, '2020-02-24', '2020-04-24', 'surgery + recovery');

INSERT INTO Treatment
VALUES (6, 4, 4, '2019-04-26', '2019-05-02', 'start anti-biotics');


INSERT INTO Treatment
VALUES (7, 5, 3, '2008-06-16', '2008-06-28', 'breathing excersise');
INSERT INTO Treatment
VALUES (8, 5, 3, '2008-06-28', '2008-07-28', 'asthma medication');

INSERT INTO Treatment
VALUES (9, 6, 18, '2009-02-22', '2009-02-25', 'start medication');

INSERT INTO Treatment
VALUES (10, 7, 14, '2019-02-22', '2019-03-26', 'start Ibandronate');

INSERT INTO Treatment
VALUES (11, 8, 21, '2020-05-02', '2020-06-02', 'pelvic floor exc');

INSERT INTO Treatment
VALUES (12, 8, 21, '2020-06-02', '2020-07-02', 'progress made, stop meds');

INSERT INTO Treatment
VALUES (13, 9, 16, '2004-05-02', '2004-06-02', 'follow diet plan');

INSERT INTO Treatment
VALUES (14, 10, 2, '2020-09-05', '2020-11-05', 'CPAP');

INSERT INTO Treatment
VALUES (15, 11, 11, '2019-09-24', '2020-03-24', 'Motrin IB');

INSERT INTO Treatment
VALUES (16, 12, 23, '2020-10-19', '2020-10-24', 'AntiBiotics Course');
INSERT INTO Treatment
VALUES (17, 12, 23, '2020-10-24', '2020-10-29', 'IBuprofen');

INSERT INTO Treatment
VALUES (18, 13, 9, '2014-09-11', '2014-09-14', 'bed rest');

INSERT INTO Treatment
VALUES (19, 14, 20, '2020-10-19', '2020-10-26', 'anti-biotics');

INSERT INTO Treatment
VALUES (20, 15, 17, '2014-09-11', '2014-09-16', 'start medication');

INSERT INTO Treatment
VALUES (21, 16, 4, '2020-10-19', '2020-10-29', 'Carbamazepine');
INSERT INTO Treatment
VALUES (22, 16, 6, '2020-10-29', '2020-11-19', 'Phenytoin');

INSERT INTO Treatment
VALUES (23, 17, 6, '2021-03-12', '2021-03-12', 'IV drip');
INSERT INTO Treatment
VALUES (24, 18, 6, '2021-03-12', '2021-03-12', 'bed-rest');










