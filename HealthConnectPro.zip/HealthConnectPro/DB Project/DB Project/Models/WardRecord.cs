﻿namespace DB_Project.Models
{
    public class WardRecord
    {
        public string Ward_Name { set; get; }
        public string Speciality { set; get; }
        public string Day_sister { set; get; }
        public string Night_sister { set; get; }
        public string[] Staff_nurse { set; get; }
        public string[] Non_registered { set; get; }
        public int[] Patient_no { set; get; }
        public string[] Patient_name { set; get; }
        public int[] CU_num { set; get; }
        public int[] bed { set; get; }
        public string[] consultant_name { set; get; }
        public string[] date_admit { set; get; }

        public WardRecord()
        {
            Patient_no = new int[20];
            Patient_name = new string[20];
            CU_num = new int[20];
            bed = new int[20];
            consultant_name = new string[20];
            date_admit = new string[20];
            Staff_nurse = new string[5];
            Non_registered = new string[5];
        }

    }
}
