﻿namespace DB_Project.Models
{
    public class ConsultantTeam
    {
        public int Staff_no { get; set; }
        public string position { get; set; }
        public string name { get; set; }
        public string date_join { get; set; }

        public string[] from_date { get; set; }
        public string[] to_date { get; set; }
        public string[] estab{get;set;}
        public string[] prog_date { get; set; }
        public string[] prog_perf { get; set; }
        public string[] prog_grade { get; set; }


        public ConsultantTeam()
        {
            from_date = new string[2];
            to_date = new string[2];
            estab = new string[2];
            prog_date = new string[10];
            prog_perf = new string[10];
            prog_grade = new string[10];
        }
    }
}
