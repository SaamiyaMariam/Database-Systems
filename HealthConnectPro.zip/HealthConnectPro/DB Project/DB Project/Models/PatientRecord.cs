﻿namespace DB_Project.Models
{
    public class PatientRecord
    {
        public string Patient_Name { set; get; }
        public int Doctor_No { set; get; }
        public string Doctor_Name { set; get; }
        public string Consultant { set; get; }
        public string DOB { set; get; }

        public int[] Complaint_Code { set; get; }
        public int[,]Treatment_Code { set; get; }
        public string[] Doc_Name { set; get; }
        public string[] Start_Date { set; get; }
        public string[] End_Date { set; get; }


        public PatientRecord()
        {
            Complaint_Code = new int[10];
            Treatment_Code = new int[10,10];
            Doc_Name = new string[10];
            Start_Date = new string[10];
            End_Date = new string[10];
        }

    }
}
