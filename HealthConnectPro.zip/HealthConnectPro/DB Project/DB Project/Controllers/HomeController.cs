﻿using DB_Project.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using MlkPwgen;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Numerics;

namespace DB_Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

 
        public IActionResult Index(int PatientNo)
        {
            int teamno = 0;
            int[] comp=new int[10];
            int count = 0, count_j = 0;
            int patient_no=0;
            List<PatientRecord> pr = new List<PatientRecord>();
            PatientRecord pr1 = new PatientRecord();
            string connstring = "Server=BISMA\\SQLEXPRESS;Database=LAB11;Trusted_Connection=True";
            SqlConnection conn = new SqlConnection(connstring);
            conn.Open();


            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "Select * from Patient where PatientNo=" + PatientNo + "";
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string patient_no_str = reader["PatientNo"].ToString();
                string patientName = reader["Name"].ToString();
                string docNo_string = reader["StaffNo"].ToString();
                string dob= reader["DOB"].ToString();
                int docNo = Int32.Parse(docNo_string);
                patient_no = Int32.Parse(patient_no_str);
                pr1.Patient_Name = patientName;
                pr1.Doctor_No = docNo;
                pr1.DOB = dob;
            }
            reader.Close();

            SqlCommand cmd2 = conn.CreateCommand();
            cmd2.CommandText = "Select * from Doctor where StaffNo="+ pr1.Doctor_No + "";
            reader = cmd2.ExecuteReader();
            while (reader.Read())
            {
                string docName = reader["Name"].ToString();
                string team_no = reader["TeamNo"].ToString();
                teamno = Int32.Parse(team_no);
                pr1.Doctor_Name = docName;
              
            }
            reader.Close();


            SqlCommand cmd3 = conn.CreateCommand();
            cmd3.CommandText = "Select * from Doctor where TeamNo=" + teamno + "AND Position='Consultant'";
            reader = cmd3.ExecuteReader();
            while (reader.Read())
            {
                string Consultant = reader["Name"].ToString();
                pr1.Consultant = Consultant;

            }
            reader.Close();

            SqlCommand cmd4 = conn.CreateCommand();
            cmd4.CommandText = "Select * from Complaint where PatientNo=" + PatientNo + "";
            reader = cmd4.ExecuteReader();
            while (reader.Read())
            {
                string Compl = reader["ComplaintCode"].ToString();
                int comp_code = Int32.Parse(Compl);
                pr1.Complaint_Code[count] = comp_code;
                comp[count] = comp_code;
                count++;

            }
          
            reader.Close();
            count = 0;
            int[] doc = new int[10];
            for(int i=0;i<10;i++)
            {
                    SqlCommand cmd5 = conn.CreateCommand();
                    cmd5.CommandText = "Select * from Treatment where ComplaintCode=" + comp[i] + "";
                    reader = cmd5.ExecuteReader();
                    while (reader.Read())
                    {
                        string Treat = reader["TreatmentCode"].ToString();
                        string Start = reader["StartDate"].ToString();
                        string End = reader["EndDate"].ToString();
                        string doc_number = reader["StaffNo"].ToString();
                        int treat_code = Int32.Parse(Treat);
                        pr1.Treatment_Code[i,count_j] = treat_code;
                        Console.WriteLine(i);
                        Console.WriteLine(count_j);

                        pr1.Start_Date[i] = Start;
                        pr1.End_Date[i] = End;
                        doc[i] = Int32.Parse(doc_number);

                        count_j++;

                    }
                    reader.Close();
                    count_j = 0;
            }
            count_j = 0;
            for(int i=0;i<10;i++)
            {
                SqlCommand cmd6 = conn.CreateCommand();
                cmd6.CommandText = "Select * from Doctor where StaffNo=" + doc[i] + "";
                reader = cmd6.ExecuteReader();
                while (reader.Read())
                {
                    string doctor_name = reader["Name"].ToString();
                    pr1.Doc_Name[i] = doctor_name;

                }
                reader.Close();
            }

            
            pr.Add(pr1);
            return View(pr);


        }
   
        public IActionResult Ward(string Name)
        { 
            List<WardRecord> wr = new List<WardRecord>();
            WardRecord w1 = new WardRecord();
            int[] doctors = new int[20];
            int[] team = new int[20];
            int WardNum=0;
            int count = 0;
            int count2 = 0;
            int[] CU = new int[5];
            string connstring = "Server=BISMA\\SQLEXPRESS;Database=LAB11;Trusted_Connection=True";
            SqlConnection conn = new SqlConnection(connstring);
            conn.Open();


            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "Select * from Ward where WardName=@WName";
            SqlParameter para = new SqlParameter();
            para.ParameterName = "@WName";
            if(Name==null)
            {
                para.Value = DBNull.Value;
            }
            else
            {
                para.Value = Name;
            }
            
            cmd.Parameters.Add(para);
           
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string spec = reader["Specialty"].ToString();
                string num = reader["WardNo"].ToString();
                WardNum = Int32.Parse(num);
                w1.Speciality = spec;
            }
            reader.Close();

            SqlCommand cmd2 = conn.CreateCommand();
            cmd2.CommandText = "Select * from Nurse where WardNo=" + WardNum + " AND Type='Day Sister'";
            reader = cmd2.ExecuteReader();
            while (reader.Read())
            {
                string day_sis = reader["NurseName"].ToString();
                w1.Day_sister = day_sis;
            }
            reader.Close();

            SqlCommand cmd3 = conn.CreateCommand();
            cmd3.CommandText = "Select * from Nurse where WardNo=" + WardNum + " AND Type='Night Sister'";
            reader = cmd3.ExecuteReader();
            while (reader.Read())
            {
                string night_sis = reader["NurseName"].ToString();
                w1.Night_sister = night_sis;
            }
            reader.Close();

            SqlCommand cmd4 = conn.CreateCommand();
            cmd4.CommandText = "Select * from Nurse where WardNo=" + WardNum + " AND Type='Staff Nurse'";
            reader = cmd4.ExecuteReader();
            while (reader.Read())
            {
                string staff = reader["NurseName"].ToString();
                w1.Staff_nurse[count] = staff;
                count++;
            }
            reader.Close();
            count = 0;

            SqlCommand cmd5 = conn.CreateCommand();
            cmd5.CommandText = "Select * from Nurse where WardNo=" + WardNum + " AND Type='Non-Registered'";
            reader = cmd5.ExecuteReader();
            while (reader.Read())
            {
                string nonreg = reader["NurseName"].ToString();
                w1.Non_registered[count2] = nonreg;
                count2++;
            }
            reader.Close();
            
            count2 = 0;

            int count3 = 0;
            SqlCommand cmd6 = conn.CreateCommand();
            cmd6.CommandText = "Select * from CareUnit where WardNo=" + WardNum + "";
            reader = cmd6.ExecuteReader();
            while (reader.Read())
            {
                string careu = reader["CareUnitNo"].ToString();
                int cu_num = Int32.Parse(careu);
                CU[count3] = cu_num;
                count3++;
            }
            reader.Close();
            count3 = 0;

            int count4 = 0;
            for(int i=0;i<5;i++)
            {
                SqlCommand cmd7 = conn.CreateCommand();
                cmd7.CommandText = "Select * from Patient where CareUnitNo=" + CU[i] + "";
                reader = cmd7.ExecuteReader();
                while (reader.Read())
                {
                    string pat_no = reader["PatientNo"].ToString();
                    string pat_name = reader["Name"].ToString();
                    string cu_num = reader["CareUnitNo"].ToString();
                    string bedn = reader["BedNo"].ToString();
                    string date = reader["AdmitDate"].ToString();
                    string cons = reader["StaffNo"].ToString();
                    int cu_number = Int32.Parse(cu_num);
                    int bed_number = Int32.Parse(bedn);
                    int doc_number = Int32.Parse(cons);
                    int pat_number = Int32.Parse(pat_no);


                    w1.Patient_no[count4] = pat_number;
                    w1.Patient_name[count4] = pat_name;
                    w1.CU_num[count4] = cu_number;
                    w1.bed[count4] = bed_number;
                    w1.date_admit[count4] = date;
                    doctors[count4] = doc_number;
                    count4++;
                }
                reader.Close();
            }

            for (int i = 0; i < 20; i++)
            {
                SqlCommand cmd8 = conn.CreateCommand();
                cmd8.CommandText = "Select * from Doctor where StaffNo=" + doctors[i] + "";
                reader = cmd8.ExecuteReader();
                while (reader.Read())
                {
                    string team_no = reader["TeamNo"].ToString();
                    int team_number = Int32.Parse(team_no);
                    team[i] = team_number;
                   
                }
                reader.Close();
            }

            for (int i = 0; i < 20; i++)
            {
                SqlCommand cmd9 = conn.CreateCommand();
                cmd9.CommandText = "Select * from Doctor where TeamNo=" + team[i] + " AND Position='Consultant'";
                reader = cmd9.ExecuteReader();
                while (reader.Read())
                {
                    string cons_no = reader["Name"].ToString();
                    w1.consultant_name[i] = cons_no;

                }
                reader.Close();
            }

           
            wr.Add(w1);
            return View(wr);
        }

        public IActionResult ConsultantTeam(int StaffNum)
        {
            List<ConsultantTeam> ct= new List<ConsultantTeam>();
            ConsultantTeam t1 = new ConsultantTeam();
            int count = 0;
            string connstring = "Server=BISMA\\SQLEXPRESS;Database=LAB11;Trusted_Connection=True";
            SqlConnection conn = new SqlConnection(connstring);
            conn.Open();

            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "Select * from PreviousExperience where StaffNo=" + StaffNum + "";
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string toD = reader["ToDate"].ToString();
                string fromD = reader["FromDate"].ToString();
                string est = reader["Establishment"].ToString();

                t1.to_date[count] = toD;
                t1.from_date[count] = fromD;
                t1.estab[count] = est;
                count++;
            }
            reader.Close();

            SqlCommand cmd2 = conn.CreateCommand();
            cmd2.CommandText = "Select * from Doctor where StaffNo=" + StaffNum + "";
            reader = cmd2.ExecuteReader();
            while (reader.Read())
            {
                string name_str = reader["Name"].ToString();
                string post = reader["Position"].ToString();
                string join = reader["JoinDate"].ToString();

                t1.name = name_str;
                t1.position = post;
                t1.date_join = join;
               
            }
            reader.Close();

            int count2 = 0;

            SqlCommand cmd3 = conn.CreateCommand();
            cmd3.CommandText = "Select * from Progress where StaffNo=" + StaffNum + "";
            reader = cmd3.ExecuteReader();
            while (reader.Read())
            {
                string date_p = reader["ProgDate"].ToString();
                string perf_p = reader["Performance"].ToString();
                string grade_p = reader["Grade"].ToString();

                t1.prog_date[count2] = date_p;
                t1.prog_grade[count2] = grade_p;
                t1.prog_perf[count2] = perf_p;
                count2++;
            }
            reader.Close();


            ct.Add(t1);
            return View(ct);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}